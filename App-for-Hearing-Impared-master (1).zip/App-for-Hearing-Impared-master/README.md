# Surrounding Audio Visualization App For Hearing Impared

An App that will help people with hard of hearing to visualize the sounds around them especially those coming from out of their field of vision.
